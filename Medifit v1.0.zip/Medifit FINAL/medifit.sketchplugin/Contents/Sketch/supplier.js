var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/supplier.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/allgSupply.js":
/*!***************************!*\
  !*** ./src/allgSupply.js ***!
  \***************************/
/*! exports provided: allgCon, allgMed, allgProc */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "allgCon", function() { return allgCon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "allgMed", function() { return allgMed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "allgProc", function() { return allgProc; });
var allgCon = ["Allergic Rhinitis", "Allergic Asthma", "Anaphylaxis", "Hives (Urticaria)", "Food Allergy", "Sinusitis", "Drug Allergy", "Lactose Intolerance", "Insect Allergy", "Latex Allergy", "Cell-Mediated Contact Dermatitis (Type IV)", "Irritant Contact Dermatitis", "IgE-Mediated Latex Allergy (Type I)", "Hay Fever", "Mold Allergy", "Pet Allergy", "Seasonal Allergic Rhinitis"];
var allgMed = ["Acravistine (Semprex-D)", "Prompheniramine", "Carbinoxamine", "Cetirizine (Zyrtec)", "Chlopheniramine (Chlortrimeton)", "Clemastine (Tavist Allergy)", "Cyproheptadine", "Desloratadine (Clarinex)", "Diphenhydramine (Benadryl)", "Fexofenadine (Allegra)", "Hydroxyzine (Pamoate)", "Hydroxyzine (Vistaril)", "Levocetirizine (Xyzal)", "Loratadine (Alavert)", "Loratadine (Claratin)", "Loratadine (Claratin-D12)", "Dupilumab (Dupixent)", "Omalizumab (Xolair)", "Montelukast (Singulair)", "Azelastine (Astelin)", "Azelastine/Fluticasone Propionate (Dymista)", "Beclomethasone Diproprionate (Q-Nasl)", "Budesonide (Rhinocort)", "Ciclesonide (Omnaris)", "Cromolyn Sodium (Nasalcrom)", "Flunisolide", "Fluticasone Furoate (Flonase)", "Fluticasone Furoate (Sensimist)", "Fluticasone Proprionate (Flonase)", "Fluticasone Propionate 93 Mg (Xhance)", "Ipratropium Bromide (Atrovent)", "Mometasone Furoate Monohydrate (Nasonex)", "Oxymetazoline (Afrin)", "Oxymetazoline (Other)", "Triamcinolone Acetonide (Nasacort AQ)", "Hydroxypropyl Methylcellulose (Alzair)", "Alcaftadine (Lastacraft)", "Azelastine (Optivar)", "Azelastine (Generic)", "Bepotastine (Beprive)", "Cromolyn (Crolom)", "Emadastine (Emadine)", "Epinastine (Elestat)", "Ketorolac (Acular)", "Ketotifen (Zaditor)", "Lodoxamine (Alomide)", "Loteprednol (Alrex)", "Loteprednol (Lotemax)", "Naphazoline (AK-Con)", "Naphazoline (Vasocon)", "Naphazoline (Albalon)", "Naphazoline (Generic)", "Naphazoline/Pheniramine (Naphcon A)", "Naphazoline/Pheniramine (Opcon-A)", "Naphazoline/Pheniramine (Visine-A)", "Naphazoline/Pheniramine (Generic)", "Nedocromil (Alocril)", "Olopatadine (Patanol)", "Olopatadine (Pataday)", "Olopatadine (Pazeo)", "Pemirolast (Alamast)", "Epinephrine (Adrenaclick)", "Epinephrine (Auvi-Q)", "Epinephrine (EpiPen)", "Epinephrine (EpiPen Jr.)", "Epinephrine (USP Auto-injector)", "Epinephrine (Authorized Generic)", "Cortisone Acetate", "Dexamethasone", "Hydrocortisone (Cortef)", "Hydrocortisone (Generic)", "Methylprednisolone (Medrol)", "Methylprednisolone (Generic)", "Prednisolone (Orapred)", "Prednisolone (Prelone)", "Prednisolone (Generic)", "Prednisone (Generic)"];
var allgProc = ["Allergy Shot (Pollen)", "Allergy Shot (Pets)", "Allergy Shot (Dust)", "Allergy Shot (Insect Venom)", "Allergy Shot (Asthma Prevention)", "Sublingual Immunotherapy (SLIT) (Dust)", "Sublingual Immunotherapy (SLIT) (Grass)", "Sublingual Immunotherapy (SLIT) (Ragweed)"];


/***/ }),

/***/ "./src/cancSupply.js":
/*!***************************!*\
  !*** ./src/cancSupply.js ***!
  \***************************/
/*! exports provided: cancCon, cancMed, cancProc */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cancCon", function() { return cancCon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cancMed", function() { return cancMed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cancProc", function() { return cancProc; });
var cancCon = ["Acute Lymphocytic Leukemia (ALL)", "Acute Myeloid Leukemia (AML)", "Adrenal Cancer", "Anal Cancer", "Basal/Squamous Cell Skin Cancer", "Bile Duct Cancer", "Bladder Cancer", "Bone Cancer", "Brain/Spinal Cord Tumor", "Breast Cancer", "Castleman Disease", "Chronic Lymphocytic Leukemia (CLL)", "Chronic Myeloid Leukemia (CML)", "Chronic Myelomonocytic Leukemia (CMML)", "Colorectal Cancer", "Endometrial Cancer", "Esophagus Cancer", "Ewing Sarcoma", "Ocular Melanoma (Eye Cancer)", "Gallbladder Cancer", "Gastrointestinal Neuroendrocrine Tumors", "Gastrointestinal Stromal Tumor (GIST)", "Gestational Trophoblastic Disease", "Hodgkin Lymphoma", "Kaposi Sarcoma", "Kidney Cancer", "Laryngeal and Hypopharyngeal Cancer", "Leukemia", "Liver Cancer", "Lung Cancer", "Lymphoma", "Malignant Mesothelioma", "Melanoma Skin Cancer", "Merkel Cell Skin Cancer", "Multiple Myeloma", "Myelodysplastic Syndrome", "Nasal/Paranasal Sinus Cancer", "Nasopharyngeal Cancer", "Neuroblastomas", "Non-Hodgkin Lymphoma", "Oral Cavity/Oropharyngeal Cancer", "Osteosarcoma", "Ovarian Cancer", "Pancreatic Cancer", "Pancreatic Neuroendrocrine Tumor (NET)", "Penile Cancer", "Pituitary Gland Cancer", "Prostate Cancer", "Retinoblastomas", "Rhabdomyosarcoma", "Salivary Gland Cancer", "Skin Cancer", "Small Intestine Cancer", "Soft Tissue Sarcoma", "Stomach Cancer", "Testicular Cancer", "Thymus Cancer", "Thyroid Cancer", "Uterine Sarcoma", "Vaginal Cancer", "Vulvar Cancer", "Waldenstrom Macroglobulinemia", "Wilms Tumor"];
var cancMed = ["Abemaciclib", "Abiraterone Acetate", "Paclitaxel Albumin-stabilized Nanoparticle Formulation (Abraxane)", "ABVD", "ABVE", "ABVE-PC", "AC", "Acalabrutinib", "AC-T", "Tocilizumab (Actemra)", "Brentuximab Vedotin (Adcetris)", "ADE", "Ado-Trastuzumab Emtansine", "Doxorubicin Hydrochloride (Adriamycin)", "Afatinib Dimaleate", "Everolimus (Afinitor)", "Netupitant and Palonosetron Hydrochloride (Akynzeo)", "Imiquimod (Aldara)", "Aldesleukin", "Alectinib (Alecensa)", "Alemtuzumab", "Pemetrexed Disodium (Alimta)", "Copanlisib Hydrochloride (Aliqopa)", "Melphalan Hydrochloride (Alkeran Injection)", "Melphalan (Alkeran Tablets)", "Palonosetron Hydrochloride (Aloxi)", "Alpelisib", "Aminolevulinic Acid Hydrochloride (Ameluz)", "Amifostine", "Brigatinib (Alunbrig)", "Aminolevulinic Acid Hydrochloride", "Anastrozole", "Apalutamide", "Aprepitant", "Darbepoetin Alfa (Aranesp)", "Pamidronate Disodium (Aredia)", "Anastrozole (Arimidex)", "Exemestane (Aromasin)", "Nelarabine (Arranon)", "Arsenic Trioxide", "Ofatumumab (Arzerra)", "Asparaginase Erwinia Chrysanthemi", "Calaspargase Pegol-mknl (Asparlas)", "Atezolizumab", "Avapritinib", "Bevacizumab (Avastin)", "Avelumab", "Axicabtagene Ciloleucel", "Axitinib", "Avapritinib (Ayvakit)", "Azacitidine", "Iobenguane I 131 (Azedra)", "Erdafitinib (Balversa)", "Avelumab (Bavencio)", "BEACOPP", "Belinostat (Beleodaq)", "Belinostat", "Bendamustine Hydrochloride", "Bendamustine Hydrochloride (Bendeka)", "BEP", "Inotuzumab Ozogamicin (Besponsa)", "Bevacizumab", "Bexarotene", "Bicalutamide", "Carmustine (BiCNU)", "Binimetinib", "Bleomycin Sulfate", "Blinatumomab", "Blinatumomab (Blincyto)", "Bortezomib", "Bosutinib (Bosulif)", "Bosutinib", "Encorafenib (Braftovi)", "Brentuximab Vedotin", "Brigatinib", "Zanubrutinib (Brukinsa)", "BuMel", "Busulfan", "Busulfan (Busulfex)", "Cabazitaxel", "Caplacizumab-yhdp (Cablivi)", "Cabozantinib-S-Malate (Cabometyx)", "Cabozantinib-S-Malate", "CAF", "Calaspargase Pegol-mknl", "Acalabrutinib (Calquence)", "Alemtuzumab (Campath)", "Irinotecan Hydrochloride (Camptosar)", "Capecitabine", "Caplacizumab-yhdp", "CAPOX", "Fluorouracil (Carac)", "Carboplatin", "Carboplatin-Taxol", "Carfilzomib", "Carmustine", "Carmustine Implant", "Bicalutamide (Casodex)", "CEM", "Cemiplimab-rwlc", "Ceritinib", "Daunorubicin Hydrochloride (Cerubidine)", "Recombinant HPV Bivalent Vaccine (Cervarix)", "Cetuximab", "CEV", "Chlorambucil", "Chlorambucil-Prednisone", "CHOP", "Cisplatin", "Cladribine", "Clofarabine", "Clofarabine (Clolar)", "CMF", "Cobimetinib", "Cabozantinib-S-Malate (Cometriq)", "Copanlisib Hydrochloride", "COPDAC", "Duvelisib (Copiktra)", "COPP", "COPP-ABV", "Dactinomycin (Cosmegen)", "Cobimetinib (Cotellic)", "Crizotinib", "CVP", "Cyclophosphamide", "Cytarabine", "Dabrafenib Mesylate", "Dacarbazine", "Ramucirumab (Cyramza)", "Decitabine (Dacogen)", "Dacomitinib", "Dactinomycin", "Daratumumab", "Darbepoetin Alfa", "Darolutamide", "Daunorubicin Hydrochloride", "Daratumumab (Darzalex)", "Dasatinib", "Daunorubicin Hydrochloride/Cytarabine Liposome", "Glasdegib Maleate (Daurismo)", "Decitabine", "Defibrotide Sodium", "Defibrotide Sodium (Defitelio)", "Degarelix", "Denileukin Diftitox", "Denosumab", "Dexamethasone", "Dexrazoxane Hydrochloride", "Dinutuximab", "Docetaxel", "Doxorubicin Hydrochloride Liposome (Doxil)", "Doxorubicin Hydrochloride", "Doxorubicin Hydrochloride Liposome", "Durvalumab", "Duvelisib", "Fluorouracil (Efudex)", "Leuprolide Acetate (Eligard)", "Rasburicase (Elitek)", "Epirubicin Hydrochloride (Ellence)", "Elotuzumab", "Oxaliplatin (Eloxatin)", "Eltrombopag Olamine", "Tagraxofusp-erzs (Elzonris)", "Emapalumab-lzsg", "Aprepitant (Emend)", "Elotuzumab", "Enasidenib Mesylate", "Encorafenib", "Enfortumab Vedotin-ejfv", "Fam-Trastuzumab Deruxtecan-nxki (Enhertu)", "Entrectinib", "Enzalutamide", "Epirubicin Hydrochloride", "EPOCH", "Epoetin Alfa", "Epoetin Alfa (Epogen)", "Cetuximab (Erbitux)", "Erdafitinib", "Eribulin Mesylate", "Vismodegib (Erivedge)", "Apalutamide (Erleada)", "Erlotinib Hydrochloride", "Asparaginase Erwinia chrysanthemi (Erwinaze)", "Amifostine (Ethyol)", "Etoposide Phosphate (Etopophos)", "Etoposide", "Etoposide Phosphate", "Everolimus", "Raloxifene Hydrochloride (Evista)", "Melphalan Hydrochloride (Evomela)", "Exemestane", "Fluorouracil Injection (5-FU)", "Fluorouracil Topical (5-FU)", "Fam-Trastuzumab Deruxtecan-nxki", "Toremifene (Fareston)", "Panobinostat (Farydak)", "Fulvestrant (Faslodex)", "FEC", "Fedratinib Hydrochloride", "Letrozole (Femara)", "Filgrastim", "Degarelix (Firmagon)", "Fludarabine Phosphate", "Fluorouracil Topical (Fluoroplex)", "Fluorouracil Injection", "Fluorouracil Topical", "Flutamide", "Folfiri", "Folfiri-Bevacizumab", "Folfiri-Cetuximab", "Folfirinix", "Folfox", "Pralatrexate (Folotyn)", "Fostamatinib Disodium", "FU-LV", "Fulvestrant", "Emapalumab-lzsg (Gamifant)", "Recombinant HPV Quadrivalent Vaccine (Gardasil)", "Recombinant HPV Nonavalent Vaccine (Gardasil 9)", "Obinutuzumab (Gazyva)", "Gefitinib", "Gemcitabine Hydrochloride", "GEMCITABINE-CISPLATIN", "GEMCITABINE-OXALIPLATIN", "Gemtuzumab Ozogamicin", "Gemcitabine Hydrochloride (Gemzar)", "Afatinib Dimaleate (Gilotrif)", "Gilteritinib Fumarate", "Glasdegib Maleate", "Imatinib Mesylate (Gleevec)", "Carmustine Implant (Gliadel Wafer)", "Glucarpidase", "Goserelin Acetate", "Granisetron", "Granisetron Hydrochloride", "Filgrastim (Granix)", "Eribulin Mesylate (Halaven)", "Propranolol Hydrochloride (Hemangeol)", "Trastuzumab/Hyaluronidase-oysk (Herceptin Hylecta)", "Trastuzumab Herceptin (Herceptin)", "Recombinant HPV Bivalent Vaccine", "Recombinant HPV Nonavalent Vaccine", "Recombinant HPV Quadrivalent Vaccine", "Topotecan Hydrochloride (Hycamtin)", "Hydroxyurea (Hydrea)", "Hydroxyurea", "Hyper-CVAD", "Palbociclib (Ibrance)", "Ibritumomab Tiuxetan", "Ibrutinib", "ICE", "Ponatinib Hydrochloride (Iclusig)", "Idarubicin Hydrochloride (Idamycin PFS)", "Idarubicin Hydrochloride", "Idelalisib", "Enasidenib Mesylate (Idhifa)", "Ifosfamide (Ifex)", "Ifosfamide", "Aldesleukin (IL-2)", "Imatinib Mesylate", "Ibrutinib (Imbruvica)", "Durvalumab (Imfinzi)", "Imiquimod", "Talimogene Laherparepvec (Imlygic)", "Axitinib (Inlyta)", "Inotuzumab Ozogamicin", "Fedratinib Hydrochloride (Inrebic)", "Recombinant Interferon Alfa-2b", "Aldesleukin (Proleukin)", "Recombinant Interferon Alfa-2b (Intron A)", "Iobenguane I 131", "Ipilimumab", "Gefitinib (Iressa)", "Irinotecan Hydrochloride", "Irinotecan Hydrochloride Liposome", "Isatuximab-irfc", "Romidepsin (Istodax)", "Ivosidenib", "Ixabepilone", "Ixazomib Citrate", "Ixabepilone (Ixempra)", "Ruxolitinib Phosphate (Jakafi)", "JEB", "Cabazitaxel", "Ado-Trastuzumab Emtansine (Kadcyla)", "Palifermin (Kepivance)", "Pembrolizumab (Keytruda)", "Ribociclib (Kisqali)", "Tisagenlecleucel (Kymriah)", "Carfilzomib (Kyprolis)", "Lanreotide Acetate", "Lapatinib Ditosylate", "Larotrectinib Sulfate", "Lenalidomide", "Lenvatinib Mesylate", "Lenvatinib Mesylate (Lenvima)", "Letrozole", "Leucovorin Calcium", "Chlorambucil (Leukeran)", "Leuprolide Acetate", "Aminolevulinic Acid Hydrochloride (Levulan Kerastik)", "Cemiplimab-rwlc (Libtayo)", "Lomustine", "Trifluridine and Tipiracil Hydrochloride (Lonsurf)", "Lorlatinib (Lorbrena)", "Lorlatinib", "Moxetumomab Pasudotox-tdfk (Lumoxiti)", "Leuprolide Acetate (Lupron)", "Leuprolide Acetate (Lupron Depot)", "Lutetium Lu 177-Dotatate (Lutathera)", "Lu 177-Dotatate (Lutetium)", "Olaparib (Lynparza)", "Vincristine Sulfate Liposome (Marqibo)", "Procarbazine Hydrochloride (Matulane)", "Mechlorethamine Hydrochloride", "Megestrol Acetate", "Trametinib (Mekinist)", "Melphalan", "Binimetinib (Mektovi)", "Melphalan Hydrochloride", "Mercaptopurine", "Mesna", "Mesna (Mesnex)", "Methotrexate", "Methylnaltrexone Bromide", "Midostaurin", "Mitomycin C", "Mitoxantrone Hydrochloride", "Mogamulizumab-kpkc", "Moxetumomab Pasudotox-tdfk", "Plerixafor (Mozobil)", "Mechlorethamine Hydrochloride (Mustargen)", "MVAC", "Bevacizumab (Mvasi)", "Busulfan (Myleran)", "Gemtuzumab Ozogamicin (Mylotarg)", "Paclitaxel Albumin-stabilized Nanoparticle Formulation (Paclitaxel)", "Necitumumab", "Nelarabine", "Neratinib Maleate", "Neratinib Maleate (Nerlynx)", "Netupitant/Palonosetron Hydrochloride", "Pegfilgrastim (Neulasta)", "Filgrastim (Neupogen)", "Sorafenib Tosylate (Nexavar)", "Nilutamide (Nilandron)", "Nilotinib", "Nilutamide", "Ixazomib Citrate (Ninlaro)", "Niraparib Tosylate Monohydrate", "Nivolumab", "Romiplostim (Nplate)", "Darolutamide (Nubeqa)", "Obinutuzumab", "Sonidegib (Odomzo)", "OEPA", "Ofatumumab", "OFF", "Olaparib", "Omacetaxine Mepesuccinate", "Pegaspargase (Oncaspar)", "Ondansetron Hydrochloride", "Irinotecan Hydrochloride Liposome (Onivyde)", "Denileukin Diftitox (Ontak)", "Nivolumab (Opdivo)", "OPPA", "Osimertinib Mesylate", "Oxaliplatin", "Paclitaxel", "Paclitaxel Albumin-stabilized Nanoparticle Formulation", "PAD", "Enfortumab Vedotin-ejfv (Padcev)", "Palbociclib", "Palifermin", "Palonosetron Hydrochloride", "Palonosetron Hydrochloride/Netupitant", "Pamidronate Disodium", "Panitumumab", "Panobinostat", "Pazopanib Hydrochloride", "PCV", "PEB", "Pegaspargase", "Pegfilgrastim", "Peginterferon Alfa-2b", "Peginterferon Alfa-2b (PEG-Intron)", "Pembrolizumab", "Pemetrexed Disodium", "Pertuzumab (Perjeta)", "Pertuzumab", "Pexidartinib Hydrochloride", "Alpelisib (Piqray)", "Plerixafor", "Polatuzumab Vedotin-piiq", "Polivy (Polatuzumab Vedotin-piiq)", "Pomalidomide", "Pomalidomide (Pomalyst)", "Ponatinib Hydrochloride", "Necitumumab (Portrazza)", "Mogamulizumab-kpkc (Poteligeo)", "Pralatrexate", "Prednisone", "Procarbazine Hydrochloride", "Epoetin Alfa (Procrit)", "Aldesleukin (Proleukin)", "Denosumab (Prolia)", "Eltrombopag Olamine (Promacta)", "Propranolol Hydrochloride", "Sipuleucel-T (Provenge)", "Mercaptopurine (Purinethol)", "Mercaptopurine (Purixan)", "Radium 223 Dichloride", "Raloxifene Hydrochloride", "Ramucirumab", "Rasburicase", "Ravulizumab-cwvz", "R-CHOP", "R-CVP", "Regorafenib", "Methylnaltrexone Bromide (Relistor)", "R-EPOCH", "Epoetin Alfa (Retacrit)", "Lenalidomide (Revlimid)", "Methotrexate (Rheumatrex)", "Ribociclib", "R-ICE", "Rituximab (Rituxan)", "Rituximab/Hyaluronidase (Rituxan Hycela)", "Rituximab", "Rituximab/Hyaluronidase", "Rolapitant Hydrochloride", "Romidepsin", "Romiplostim", "Entrectinib (Rozlytrek)", "Daunorubicin Hydrochloride (Rubidomycin)", "Rucaparib Camsylate (Rubraca)", "Rucaparib Camsylate", "Ruxolitinib Phosphate", "Midostaurin (Rydapt)", "Granisetron (Sancuso)", "Isatuximab-irfc (Sarclisa)", "Sclerosol Intrapleural Aerosol (Talc)", "Selinexor", "Siltuximab", "Sipuleucel-T", "Lanreotide Acetate (Somatuline Depot)", "Sonidegib", "Sorafenib Tosylate", "Dasatinib (Sprycel)", "Stanford V", "Sterile Talc Powder)", "Steritalc (Talc)", "Regorafenib (Stivarga)", "Sunitinib Malate", "Granisetron (Sustol)", "Sunitinib Malate (Sutent)", "Peginterferon Alfa-2b (Sylatron)", "Siltuximab (Sylvant)", "Omacetaxine Mepesuccinate (Synribo)", "Thioguanine (Tabloid)", "TAC", "Dabrafenib Mesylate (Tafinlar)", "Tagraxofusp-erzs", "Osimertinib Mesylate (Tagrisso)", "Talazoparib Tosylate", "Talc", "Talimogene Laherparepvec", "Talazoparib Tosylate (Talzenna)", "Tamoxifen Citrate", "Erlotinib Hydrochloride (Tarceva)", "Bexarotene (Targretin)", "Nilotinib (Tasigna)", "Fostamatinib Disodium (Tavalisse)", "Docetaxel (Taxotere)", "Tazemetostat Hydrobromide", "Tazemetostat Hydrobromide (Tazverik)", "Atezolizumab (Tecentriq)", "Temozolomide (Temodar)", "Temozolomide", "Temsirolimus", "Thalidomide", "Thalidomide (Thalomid)", "Thioguanine", "Thiotepa", "Ivosidenib (Tibsovo)", "Tisagenlecleucel", "Tocilizumab", "Fluorouracil Topical (Tolak)", "Topotecan Hydrochloride", "Toremifene", "Temsirolimus (Torisel)", "Dexrazoxane Hydrochloride (Totect)", "TPF", "Trabectedin", "Trametinib", "Trastuzumab", "Trastuzumab and Hyaluronidase-oysk", "Bendamustine Hydrochloride (Treanda)", "Methotrexate (Trexall)", "Trifluridine/Tipiracil Hydrochloride", "Arsenic Trioxide (Trisenox)", "Rituximab (Truxima)", "Pexidartinib Hydrochloride (Turalio)", "Lapatinib Ditosylate (Tykerb)", "Ravulizumab-cwvz (Ultomiris)", "Dinutuximab (Unituxin)", "Uridine Triacetate", "VAC", "Valrubicin", "Valrubicin (Valstar)", "Vandetanib", "VAMP", "Rolapitant Hydrochloride (Varubi)", "Panitumumab (Vectibix)", "VeIP", "Bortezomib (Velcade)", "Vemurafenib", "Venetoclax (Venclexta)", "Venetoclax", "Abemaciclib (Verzenio)", "Azacitidine (Vidaza)", "Vinblastine Sulfate", "Vincristine Sulfate", "Vincristine Sulfate Liposome", "Vinorelbine Tartrate", "VIP", "Vismodegib", "Uridine Triacetate (Vistogard)", "Larotrectinib Sulfate (Vitrakvi)", "Dacomitinib (Vizimpro)", "Glucarpidase (Voraxaze)", "Vorinostat", "Pazopanib Hydrochloride (Votrient)", "Daunorubicin Hydrochloride/Cytarabine Liposome (Vyxeos)", "Crizotinib (Xalkori)", "Capecitabine (Xeloda)", "Xeliri", "Xelox", "Denosumab (Xgeva)", "Radium 223 Dichloride (Xofigo)", "Gilteritinib Fumarate (Xospata)", "Selinexor (Xpovio)", "Enzalutamide (Xtandi)", "Ipilimumab (Yervoy)", "Axicabtagene Ciloleucel (Yescarta)", "Trabectedin (Yondelis)", "Ziv-Aflibercept (Zaltrap)", "Zanubrutinib", "Filgrastim (Zarxio)", "Niraparib Tosylate Monohydrate (Zejula)", "Vemurafenib (Zelboraf)", "Ibritumomab Tiuxetan (Zevalin)", "Dexrazoxane Hydrochloride (Zinecard)", "Ziv-Aflibercept", "Ondansetron Hydrochloride (Zofran)", "Goserelin Acetate (Zoladex)", "Zoledronic Acid", "Vorinostat (Zolinza)", "Zoledronic Acid (Zometa)", "Idelalisib (Zydelig)", "Ceritinib (Zykadia)", "Abiraterone Acetate (Zytiga)"];
var cancProc = ["Open Tumor Extraction", "Minimally Invasive Tumor Extraction", "Open Tumor Debulking", "Minimally Invasive Tumor Debulking", "Open Surgery (Other)", "Minimally Invasive Surgery (Other)", "Cryosurgery", "Hyperthermia (Local)", "Hyperthermia (External)", "Hyperthermia (Intraluminal)", "Hyperthermia (Interstitial)", "Hyperthermia (Deep Tissue)", "Hyperthermia (Regional Perfusion)", "Hyperthermia (Continuous Hyperthermic Peritoneal Perfusion (CHPP))", "Hyperthermia (Whole Body)", "Photodynamic Therapy", "Laser Therapy", "External Beam Radiation Therapy", "Internal Radation Therapy", "Internal Radation Therapy (Brachytherapy)", "Chemotherapy (Oral)", "Chemotherapy (Intravenous)", "Chemotherapy (Intrathecal)", "Chemotherapy (Intraperitoneal)", "Chemotherapy (Intra-arterial)", "Chemotherapy (Topical)", "Hormone Therapy (Breast Cancer)", "Hormone Therapy (Prostate Cancer)", "Stem Cell Transplant (Autologous)", "Stem Cell Transplant (Allogeneic)", "Stem Cell Transplant (Syngeneic)", "Targeted Therapy (Small-Molecule)", "Targeted Therapy (Monoclonal Antibody)", "Immunotherapy (Immune Checkpoint Inhibition)", "Immunotherapy (T-cell Transfer Therapy)", "Immunotherapy (Monoclonal Antibody)", "Immunotherapy (Treatment Vaccine)", "Immunotherapy (Immune System Modulation)"];


/***/ }),

/***/ "./src/circSupply.js":
/*!***************************!*\
  !*** ./src/circSupply.js ***!
  \***************************/
/*! exports provided: circCon, circMed, circProc */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "circCon", function() { return circCon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "circMed", function() { return circMed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "circProc", function() { return circProc; });
var circCon = ["Acute Coronary Syndrome", "Angina", "Aortic Aneurysm", "Arrhythmia", "Aortic Valve Regurgitation", "Aortic Valve Stenosis", "Atherosclerosis", "Atrial Fibrillation", "Bradycardia", "Ischemic Cardiomyopathy", "Dilated Cardiomyopathy", "Hypertrophic Cardiomyopathy", "Restrictive Cardiomyopathy", "Congenital Heart Defect", "Deep Vein Thrombosis (DVT)", "Endocarditis", "High Blood Pressure", "High Cholesterol", "Heart Block", "Heart Failure", "Heart Murmur", "Hypertension", "Hypotension", "Hyperlipidemia", "Coronary Heart Disease", "Metabolic Syndrome", "Mitral Valve Prolapse", "Mitral Valve Regurgitation", "Mitral Valve Stenosis", "Pericarditis", "Peripheral Artery Disease", "Pulmonary Embolism", "Renal Artery Disease", "Stroke", "Subclavian Artery Disease", "Supraventricular Tachycardia", "Varicose Veins", "Ventricular Tachycardia", "Heart Cancer"];
var circMed = ["Aspirin", "Apixaban (Eliquis)", "Dabigatran (Pradaxa)", "Heparin", "Edoxaban (Savaysa)", "Rivaroxaban (Xarelto)", "Warfarin (Coumadin)", "Clopidogrel (Plavix)", "Dipyridamole (Persantine)", "Prasugrel (Effient)", "Ticagrelor (Brilinta)", "Benazepril (Lotensin)", "Captopril (Capoten)", "Enalapril (Vasotec)", "Fosinopril (Monopril)", "Lisinopril (Prinivil)", "Lisinopril (Zestril)", "Moexipril (Univasc)", "Perindopril (Aceon)", "Quinapril (Accupril)", "Ramipril (Altace)", "Trandolapril (Mavik)", "Azilsartan (Edarbi)", "Candesartan (Atacand)", "Eprosartan (Teveten)", "Irbesartan (Avapro)", "Losartan (Cozaar)", "Olmesartan (Benicar)", "Telmisartan (Micardis)", "Valsartan (Diovan)", "Sacubitril (Entresto)", "Acebutolol (Sectral)", "Atenolol (Tenormin)", "Betaxolol (Kerlone)", "Bisoprolol (Zebeta)", "Bisoprolol/Hydrochlorothiazide (Ziac)", "Metoprolol (Lopressor)", "Metoprolol (Toprol XL)", "Nadolol (Corgard)", "Propranolol (Inderal)", "Sotalol (Betapace)", "Carvedilol (Coreg)", "Carvedilol (Coreg CR)", "Labetalol hydrochloride (Normodyne)", "Labetalol hydrochloride (Trandate)", "Amlodipine (Norvasc)", "Diltiazem (Cardizem)", "Diltiazem (Tiazac)", "Felodipine (Plendil)", "Nifedipine (Adalat)", "Nifedipine (Procardia)", "Nimodipine (Nimotop)", "Nisoldipine (Sular)", "Verapamil (Calan)", "Verapamil (Verelan)", "Atorvastatin (Lipitor)", "Fluvastatin (Lescol)", "Lovastatin (Mevacor)", "Pitavastatin (Livalo)", "Pravastatin (Pravachol)", "Rosuvastatin (Crestor)", "Simvastatin (Zocor)", "Ezetimibe (Zetia)", "Ezetimibe/Simvastatin (Vytorin)", "Digoxin (Lanoxin)", "Acetazolamide (Diamox)", "Amiloride (Midamor)", "Bumetanide (Bumex)", "Chlorothiazide (Diuril)", "Chlorthalidone (Hygroton)", "Furosemide (Lasix)", "Hydrochlorothiazide (Esidrix)", "Hydrochlorothiazide (Hydrodiuril)", "Indapamide (Lozol)", "Metalozone (Zaroxolyn)", "Spironolactone (Aldactone)", "Torsemide (Demadex)", "Isosorbide dinitrate (Isordil)", "Isosorbide mononitrate (Imdur)", "Hydralazine (Apresoline)", "Nitroglycerin (Nitro Bid)", "Nitroglycerin (Nitro Stat)", "Minoxidil"];
var circProc = ["Angioplasty", "Laser Angioplasty", "Atherectomy", "Cardiomyoplasty", "Heart Transplant", "Limited Access Coronary Artery Surgery", "Port-Access Coronary Artery Bypass", "Minimally Invasive Coronary Artery Bypass Graft", "Radiofrequency Ablation", "Stent Placement", "Transmyocardial Revascularization", "Open Heart Surgery (Other)", "Minimally Invasive Heart Surgery (Other)", "Heart Valve Repair", "Heart Valve Replacement", "Pacemaker Implant", "Maze Surgery", "ICD Implant", "Ventricular Assist Device Implant", "Artificial Heart Implant", "Off-Pump Heart Surgery (Other)"];


/***/ }),

/***/ "./src/diabSupply.js":
/*!***************************!*\
  !*** ./src/diabSupply.js ***!
  \***************************/
/*! exports provided: diabCon, diabMed, diabProc */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "diabCon", function() { return diabCon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "diabMed", function() { return diabMed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "diabProc", function() { return diabProc; });
var diabCon = ["Type 1 Diabetes", "Type 2 Diabetes", "Gestational Diabetes", "Diabetic Ketoacidosis", "Hypoglycemia", "Hyperglycemia", "Acanthosis Nigricans", "Diabetic Dermopathy", "Necrobiosis Lipoidica Diabeticorum", "Diabetic Blisters", "Digital Sclerosis", "Disseminated Granuloma Annulare", "Diabetic Retinopathy", "Diabetic Neuropathy", "Diabetic Nephropathy"];
var diabMed = ["Acarbose (Precose)", "Canagliflozin (Invokana)", "Dapagliflozin (Farxiga)", "Empagliflozin (Jardiance)", "Glipizide (Glucotrol)", "Glimepiride (Amaryl)", "Glyburide (DiaBeta, Glynase)", "Linagliptin (Tradjenta)", "Nateglinade (Starlix)", "Miglitol (Glyset)", "Repaglinide (Prandin)", "Saxagliptin (Onglyza)", "Regular Insulin (Humulin)", "Regular Insulin (Novolin)", "Insulin Apart (Novolog)", "Insulin Apart (FlexPen)", "Insulin Apart (Fiasp)", "Insulin Glulisine (Apidra)", "Insulin Lispro (Humalog)", "Insulin Isophane (Humulin N)", "Insulin Isophane (Novolin N)", "Insulin Degludec (Tresiba)", "Insulin Detemir (Levemir)", "Insulin Glargine (Lantus)", "Insulin Glargine (Toujeo)", "NovoLog Mix 70/30 (insulin aspart protamine-insulin aspart)", "Humalog Mix 75/25 (insulin lispro protamine-insulin lispro)", "Humalog Mix 50/50 (insulin lispro protamine-insulin lispro)", "Humulin 70/30 (human insulin NPH-human insulin regular)", "Novolin 70/30 (human insulin NPH-human insulin regular)", "Ryzodeg (insulin degludec-insulin aspart)", "Pramlintide (SymlinPen 120)", "Pramlintide (SymlinPen 60)", "Metformin (Glucophage)", "Metformin (Metformin Hydrochloride ER)", "Metformin (Glumetza)", "Metformin (Riomet)", "Metformin (Fortamet)", "Metformin-canagliflozin (Invokamet)", "Metformin-dapagliflozin (Xigduo XR)", "Metformin-empagliflozin (Synjardy)", "Metformin-glipizide", "Metformin-glyburide (Glucovance)", "Metformin-linagliptin (Jentadueto)", "Metformin-pioglitazone (Actoplus)", "Metformin-repaglinide (Prandimet)", "Metformin-rosiglitazone (Avandamet)", "Metformin-saxagliptin (Kombiglyze XR)", "Bromocriptine (Cycloset)", "Alogliptin (Nesina)", "Alogliptin-metformin (Kazano)", "Alogliptin-pioglitazone (Oseni)", "Linagliptin (Tradjenta)", "Linagliptin-empagliflozin (Glyxambi)", "Saxagliptin (Onglyza)", "Saxagliptin-metformin (Kombiglyze XR)", "Sitagliptin (Januvia)", "Sitagliptin-metformin (Janumet)", "Sitagliptin-metformin (Janumet XR)", "Sitagliptin and Simvastatin (Juvisync)", "Albiglutide (Tanzeum)", "Dulaglutide (Trulicity)", "Exenatide (Byetta)", "Exenatide extended-release (Bydureon)", "Liraglutide (Victoza)", "Semaglutide (Ozempic)", "Ertugliflozin (Steglatro)", "Glimepiride-pioglitzaone (Duetact)", "Glimepiride-rosiglitazone (Avandryl)", "Gliclazide", "Glipizide-metformin (Metaglip)", "Glyburide (Micronase)", "Chlorpropamide (Diabinese)", "Tolazamide (Tolinase)", "Tolbutamide (Orinase)", "Tolbutamide (Tol-Tab)", "Rosiglitazone (Avandia)", "Rosiglitazone-metformin (Amaryl M)", "Pioglitazone (Actos)"];
var diabProc = ["Bariatric Surgery (Other)", "Roux-en-Y Gastric Bypass", "Sleeve Gastrectomy", "Gastric Band Implant", "Biliopancreatic Diversion with Duodenal Switch"];


/***/ }),

/***/ "./src/digSupply.js":
/*!**************************!*\
  !*** ./src/digSupply.js ***!
  \**************************/
/*! exports provided: digCon, digMed, digProc */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "digCon", function() { return digCon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "digMed", function() { return digMed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "digProc", function() { return digProc; });
var digCon = ["Abdominal Adhesion", "Acid Reflux (GERD)", "Anorectal Malformation", "Colonic Atresia & Stenosis", "Malrotation", "Intussusception", "Colonic Fistula", "Anorectal Fistula", "Rectal Prolapse", "Colonic Volvulus", "Appendicitis", "Barrett's Esophagus", "Fecal Incontinence", "Celiac Disease", "Chronic Diarrhea", "Colon Polyps", "Constipation", "Chrohn's Disease", "Cyclic Vomiting Syndrome", "Diverticular Disease", "Dumping Syndrome", "Gallstones", "Gastritis", "Gastrointestinal Bleeding", "Gastroparesis", "Hemorrhoids", "Hirschsprung Disease", "Chronic Dyspepsia", "Inguinal Hernia", "Intestinal Pseudo-obstruction", "Irritable Bowel Syndrome (IBS)", "Lactose Intolerance", "Menetrier's Disease", "Microscopic Colitis", "Pancreatitis", "Peptic Ulcers", "Proctitis", "Short Bowel Syndrome", "Ulcerative Colitis", "Whipple Disease", "Zollinger-Ellison Syndrome"];
var digMed = ["Rabeprazole (Aciphex)", "Analpram", "Mesalamine (Asacol)", "Mesalamine (Apriso)", "Diphenoxylate (Colonaid)", "Azathioprine (Azasan)", "Azathioprine (Imuran)", "Sulfasalazine (Azulfidine)", "Lubiprostone (Amitiza)", "Colazal (Balsazide)", "Dicyclomine (Bentyl)", "Clarithromycin (Biaxin)", "Bismuth", "Budesonide", "Entecavir (Baraclude)", "Calcium Carbonate", "Mesalamine (Canasa)", "Sucralfate (Carafate)", "Chlordiazepoxide/Clidinium (Librax)", "Cholestyramine Resin (Questran)", "Cimetidine", "Ciprofloxacin", "Citricel", "Clarithromycin", "Clidinium", "Colace", "Colyte", "Prochlorperazine (Compazine)", "Cortenema", "Pancrelipase (Creon)", "Misoprostol (Cytotec)", "Certolizumab (Cimzia)", "Diphenoxylate/Atropine (Lomotil)", "Alosetron (Lotronex)", "Loperamide (Imodium)", "Simethicone (Maalox)", "Mercaptopurine (Purinethol)", "Mercaptopurine (GMP)", "Psyllium (Metamucil)", "Metoclopramide (Reglan)", "Magnesium Hydroxide (Milk of Magnesia)", "Polyethylene Glycol 3350 (Miralax)", "Aluminum Hyrdoxide (Mylanta)", "Simethicone (Mylicon)", "Cyclosporine (Neoral)", "Esomaprazole (Nexium)", "Nitroglycerin (Niferex)", "Omeprazole (Prilosec)", "Pancrelipase (Pancrease)", "Pantroprazole (Protonix)", "Mesalamine (Pentasa)", "Famotidine (Pepcid)", "Famotidine (Duexis)", "Bismuth Subsalicylate (Pepto-Bismol)", "Peri-Colace", "Simethicone (Phazyme)", "Lansoprazole (Prevacid)", "Lansoprazole (Prevpac)", "Ranitidine (Zantac)", "Pancrelipase (Viokase)", "Doxycycline (Vibramycin)", "Ursodiol", "Bethanechol (Urecholine)", "Cimetidine (Tagamet)", "Tacrolimus", "Tetracycline", "Calcium Carbonate (Titralac)", "Amoxicillin (Trimox)"];
var digProc = ["Barium Swallow/Meal", "Gastroscopy", "Endoscopic Retrograde Cholangiopancreatography (ERCP)", "Endoscopic Ultrasound", "pH Monitoring", "Esophageal/Gastric Manometry", "Colonoscopy", "Barium Enema", "Flexible Sigmoidoscopy", "Virtual Colonoscopy", "Capsule Endoscopy", "Anorectal Manometry", "Fecal Calprotectin", "Fecal Occult Blood Test", "Fecal Immunochemical Test (FIT)", "Hydrogen Breath Test", "Lactose Intolerance Test", "Stool Acidity Test", "Liver Biopsy", "FibroScan", "Magnetic Resonance Imaging", "Ultrasound", "H. pylori Breath Test"];


/***/ }),

/***/ "./src/glandSupply.js":
/*!****************************!*\
  !*** ./src/glandSupply.js ***!
  \****************************/
/*! exports provided: glandCon, glandMed, glandProc */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "glandCon", function() { return glandCon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "glandMed", function() { return glandMed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "glandProc", function() { return glandProc; });
var glandCon = ["Acromegaly", "Adrenal Insufficiency", "Addison's Disease", "Cushing's Syndrome", "Graves' Syndrome", "Hashimoto's Disease", "Hyperthyroidism", "Hypothyroidism", "Multiple Endrocine Neoplasia Type 1", "Primary Hyperparathyroidism", "Prolactinoma"];
var glandMed = ["Oxymetholone (Anadrol-50)", "Fluoxymesterone (Androxy)", "Fluoxymesterone (Halotestin)", "Topical Testosterone (Androderm)", "Topical Testosterone (AndroGel)", "Topical Testosterone (Testim)", "Topical Testosterone (Axiron)", "Topical Testosterone (Fortesta)", "Topical Testosterone (Vogelxo)", "Methyltestosterone (Android)", "Methyltestosterone (Methitest)", "Methyltestosterone (Testred)", "Testosterone (Aveed)", "Testosterone (Depo-Testosterone)", "Testosterone (Testopel)", "Testosterone (Xyosted)", "Testosterone (Jatenzo)", "Danazol", "Intranasal Testosterone (Natesto)", "Oxandrolone (Oxandrin)", "Buccal Tesosterone (Striant)", "Darolutamide (Nubeqa)", "Sodium Iodide I-131 (Hicon)", "Potassium Iodide (Pima Syrup)", "Potassium Iodide (SSKI)", "Potassium Iodide (Iosat)", "Potassium Iodide (ThyroSafe)", "Potassium Iodide (ThyroShield)", "Methimazole (Northyx)", "Methimazole (Tapazole)", "Propylthiouracil (PTU)", "Risedronate (Actonel)", "Risedronate (Atelvia)", "Risedronate (Actonel w/ Calcium)", "Alendronate (Fosamax)", "Alendronate (Binosto)", "Alendronate (Fosamax Plus D)", "Ibandronate (Boniva)", "Etidronate (Didronel)", "Zolendronic Acid (Reclast)", "Zolendronic Acid (Zometa)", "Cinacalcet (Sensipar)", "Etelcalcetide (Parsabiv)", "Trientine (Syprine)", "Trientine (Clovique)", "Methylprednisolone (Medrol)", "Methylprednisolone (Medrol Dosepak)", "Methylprednisolone (DepoMedrol)", "Methylprednisolone (SoluMedrol)", "Methylprednisolone (A-Methapred)", "Mifepristone (Mifeprex)", "Mifepristone (Korlym)", "Mifepristone (RU486)", "Cortcorelin (Acthrel)", "Arginine (L-arginine)", "Arginine (RGene-10)", "Secretin (ChiRhoStim)", "Corticorelin (Acthrel)", "Cosyntropin (Cortrosyn)", "Cosyntropin (Synthetic ACTH)", "Macimorelin (Macrilen)", "Metyrapone (Metopirone)", "Thyrotropin Alfa (Thyrogen)", "Fenoldopam (Corlopam)", "Sapropterin (Kuvan)", "Miglustat (Zavesca)", "Agalsidase Alfa (Replagal)", "Agalsidase Beta (Fabrazyme)", "Iaronidase (Aldurazyme)", "Alglucosidase Alfa (Lumizyme)", "Alglucosidase Alfa (Myozyme)", "Asfotase Alfa (Strensiq)", "Imiglucerase (Cerezyme)", "Elapegademase (Revcovi)", "Elapegademase (Elapegademase-LVLR)", "Idursulfase (Elaprase)", "Taliglucerase Alfa (Elelyso)", "Elosulfase Alfa (Vimizim)", "Galsulfase (Naglazyme)", "Sebelipase Alfa (Kanuma)", "Pegvaliase (PAL)", "Pegvaliase (Pevaliase-pqpz)", "Pegvaliase (Palynziq)", "Sacrosidase (Sucraid)", "Uridine Triacetate (Xuriden)", "Uridine Triacetate (Vistogard)", "Velaglucerase Alfa (VPRIV)", "Estrogen/Methyltestosterone (Covaryx)", "Estrogen/Methyltestosterone (Estratest)", "Estrogen/Methyltestosterone (Estratest H.S.)", "Intranasal Glucagon (Baqsimi)", "Dextrose (D50W)", "Dextrose (DGlucose)", "Diazoxide (Proglycem)", "Glucagon", "Glucagon Emergency Kit", "Glucagon (GlucaGen HypoKit)", "Glucagon (Gvoke)", "Somatropin (Genotropin)", "Somatropin (HumatroPen)", "Somatropin (Genotropin Miniquick)", "Somatropin (Genotropin Pen 12)", "Somatropin (Humatrope)", "Somatropin (Norditropin FlexPro)", "Somatropin (Norditropin NordiFlex)", "Somatropin (Nutropin)", "Somatropin (Nutropin AQ)", "Somatropin (Nutropin AQ Nuspin 20)", "Somatropin (Nutropin AQ Nuspin 10)", "Somatropin (Nutropin AQ Nuspin 5)", "Somatropin (Omnitropin)", "Somatropin (Saizen)", "Somatropin (Serostim)", "Somatropin (Zorbtive)", "Somatropin (Nutropin AQ Pen 20)", "Somatropin (Nutropin AQ Pen 10)", "Somatropin (Zomacton)", "Arginine (L-arginine)", "Arginine (RGene-10)", "Tesamorelin (Egrifta)", "Betaine (Cystadane)", "Bromocriptine (Cycloset)", "Cabergoline (Dostinex)", "Metreleptin (Myalept)", "Bremelanotide (Vyleesi)", "Abaloparatide (Tymlos)", "Teriparatide (Forteo)", "Teriparatide", "Teriparatide (Bonsity)", "Recombinant Human Parathyroid Hormone (Natpara)", "Ferric Citrate (Auryxia)", "Calcium Acetate (Eliphos)", "Calcium Acetate (PhosLo)", "Calcium Acetate (Phoslyra)", "Calcium Acetate (Calphron)", "Lanthanum Carbonate (Fosrenol)", "Sevelamer (Renagel)", "Sevelamer (Renvela)", "Sucroferric Oxyhydroxide (Velphoro)", "Oxytocin (Pitocin)", "Tolvaptan (Samsca)", "Tolvaptan (Jynarque)", "Olisodrostat", "Allogeneic Thymic Tissue", "Carboprost Tromethamine (Hemabate)", "Dinoprostone (Cervidil)", "Dinoprostone (Prepidil)", "Dinoprostone (Prostaglandin E2)", "Dinoprostone (Prostin E2)", "Misoprostol (Cytotec)", "Lanreotide (Somatuline Depot)", "Octreotide (Sandostatin)", "Octreotide (Sandostatin LAR)", "Octreotide (Bynfezia Pen)", "Pasireotide (Signifor)", "Pasireotide (Signifor LAR)", "Thyroid Desiccated (Armour Thyroid)", "Thyroid Desiccated (Nature-Throid)", "Liothyronine (Cytomel)", "Liothyronine (Triostat)", "Liothyronine (Liothyronine T3)", "Liothyronine (Thyroid Hormone)", "Levothyroxine (Synthroid)", "Levothyroxine (Levoxyl)", "Levothyroxine (L Thyroxine)", "Levothyroxine (Levo T)", "Levothyroxine (Levothroid)", "Levothyroxine (Levothyroxine T4)", "Levothyroxine (Levoxine)", "Levothyroxine (Tirosint)", "Levothyroxine (Tirosint-SOL)", "Levothyroxine (Unithroid)", "Liotrix (Thyrolar)", "Sodium Benzoate/Sodium Phenylacetate (Ammonul)", "Sodium Phenylbutyrate (Buphenyl)", "Sodium Phenylbutyrate", "Carglumic Acid (Carbaglu)", "Glycerol Phenylbutyrate (Ravicti)", "Vasopressin (ADH)", "Vasopressin (Vasostrict)", "Conivaptan (Vaprisol)", "Desmopressin (DDAVP)", "Desmopressin (Stimate)", "Desmopressin (Minirin)", "Desmopressin (Noctiva)", "Desmopressin (Nocdurna)", "Calcifediol (Rayaldee)", "Calcitriol (Calcijex)", "Calcitriol (Rocaltrol)", "Doxercalciferol (Hectorol)", "Paricalcitol (Zemplar)", "Burosumab (Crysvita)", "Burosumab (Burosumab-twza)", "Denosumab (Prolia)", "Denosumab (Xgeva)", "Romosozumab (Evenity)", "Romosozumab (Romosozumab-aqqg)", "Teprotumumab (Tepezza)", "Teprotumumab (Teprotumumab-trbw)", "Becaplermin (Regranex Gel)", "Cerliponase Alfa (Brineura)", "Cerliponase Alfa (RHTPP1)", "Levocarnitine (Carnitor)", "Levocarnitine (Carnitine)", "Eliglustat (Cerdelga)", "Cysteamine (Cystagon)", "Cysteamine (Procysbi)", "Dichlorphenamide (Keveyis)", "Vestronidase Alfa-vjbk (Mepsevii)", "Nitisinone (Orfadin)", "Nitisinone (Nityr)", "Pegvisomant (Somavert)"];
var glandProc = ["Adrenalectomy", "Parathyroidectomy", "Thyroidectomy", "Thyroid lobectomy", "Total Pancreatectomy", "Open Endocrine Surgery (Other)", "Minimally Invasive Endocrine Surgery (Other)", "Laparoscopic Surgery (Other)", "Insulinoma Enucleation", "Pancreatic Enucleation", "Parotidectomy", "Magnetic Resonance Imagery (MRI)"];


/***/ }),

/***/ "./src/mentSupply.js":
/*!***************************!*\
  !*** ./src/mentSupply.js ***!
  \***************************/
/*! exports provided: mentCon, mentMed, mentProc */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mentCon", function() { return mentCon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mentMed", function() { return mentMed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mentProc", function() { return mentProc; });
var mentCon = ["General Despression", "Panic Disorder", "Obsessive-Compulsive Disorder", "Post-Traumatic Stress Disorder", "Phobia", "Generalized Anxiety Disorder", "Post-Partum Depression", "Seasonal Affective Disorder", "Bipolar Disorder", "Sleep Disorder", "Substance Abuse", "Bulimia Nervosa", "Anorexia Nervosa", "Borderline Personality Disorder", "Narcissistic Personality Disorder", "Paranoia", "Delusional Disorder", "Schizoid Personality Disorder", "Schizotypal Personality Disorder", "Antisocial Personality Disorder", "Psychosis", "Schizophrenia", "Schizoaffective Disorder", "Hallucinations", "Brain Injury", "Autism", "Alzheimer's Disease", "Dissociative Disorder"];
var mentMed = ["Fluoxetine (Prozac)", "Fluoxetine (Prozac Weekly)", "Fluoxetine (Rapiflux)", "Fluoxetine (Sarafem)", "Fluoxetine (Selfemra)", "Citalopram (Celexa)", "Sertraline (Zoloft)", "Peroxetine (Brisdelle)", "Peroxetine (Paxil)", "Peroxetine (Paxil CR)", "Peroxetine (Pexeva)", "Escitalopram (Lexapro)", "Duloxetine (Cymbalta)", "Venlafaxine (Generic)", "Buproprion (Aplenzin)", "Buproprion (Forfivo XL)", "Buproprion (Wellbutrin)", "Buproprion (Wellbutrin SR)", "Buproprion (Wellbutrin XL)", "Buproprion (Zyban)", "Tricyclics (Generic)", "Tetracyclics (Generic)", "Monoamine Oxidase Inhibitor (Generic)", "Clonazepam (Klonopin)", "Alprazolam (Xanax)", "Alprazolam (Xanax XR)", "Lorazepam (Ativan)", "Lorazepam (Lorazepam Intensol)", "Benzodiazepine (Generic)", "Buspirone (Generic)", "Methylphenidylacetate Hydrochloride (Adhansia XR)", "Methylphenidylacetate Hydrochloride (Aptensio XR)", "Methylphenidylacetate Hydrochloride (Concerta)", "Methylphenidylacetate Hydrochloride (Cotempla XR-ODT)", "Methylphenidylacetate Hydrochloride (Jornay PM)", "Methylphenidylacetate Hydrochloride (Metadate CD)", "Methylphenidylacetate Hydrochloride (Methylin)", "Methylphenidylacetate Hydrochloride (Quillichew XR)", "Methylphenidylacetate Hydrochloride (Quillivant XR)", "Methylphenidylacetate Hydrochloride (Ritalin LA)", "Dextroamphetamine (Dexedrine)", "Amphetamine/Dextroamphetamine (Adderall)", "Amphetamine/Dextroamphetamine (Adderall XR)", "Lisdexamfetamine (Vyvanse)", "Atomoxetine (Generic)", "Clonidine (Catapres)", "Clonidine (Kapvay)", "Clonidine/Chlorthalidone (Clorpres)", "Guanfacine (Intuniv)", "Guanfacine (Tenex)", "Chlorpromazine (Generic)", "Haloperidol (Generic)", "Perphenazine/Amitriptyline (Duo-Vil)", "Fluphenazine (Generic)", "Risperidone (Risperdol Oral Solution)", "Risperidone (Risperdol Tablets)", "Risperidone (Risperdol M-Tab)", "Olanzapine (Zyprexa)", "Olanzapine (Zyprexa Zydis)", "Quetiapine (Seroquel)", "Quetiapine (Seroquel XR)", "Ziprasidone (Geodon)", "Aripiprazole (Abilify)", "Aripiprazole (Abilify Mycite)", "Paliperidone (Invega)", "Lurasidone (Latuda)", "Carbamazepine (Carbatrol)", "Carbamazepine (Epitol)", "Carbamazepine (Equetro)", "Carbamazepine (Tegretol)", "Carbamazepine (Tegretol-XR)", "Lamotrigine (Lamictal)", "Lamotrigine (Lamictal CD)", "Lamotrigine (Lamictal ODT)", "Lamotrigine (Lamictal XR)", "Oxcarbazepine (Oxtellar XR)", "Oxcarbazepine (Trileptal)", "Valproic Acid (Depakene)", "Valproic Acid (Depakote)", "Valproic Acid (Depakote ER)", "Valproic Acid (Depakote Sprinkle)", "Lithium (Lithobid)"];
var mentProc = ["Cognitive Behavioral Therapy", "Dialectical Behavior Therapy", "Eye Movement Desensitization and Reprocessing Therapy (EMDR)", "Exposure Therapy", "Interpersonal Therapy", "Mentalization-Based Therapy", "Psychodynamic Psychotherapy", "Psychoeducation", "Psychosocial Rehabiliation", "Assertive Community Treatment (ACT)", "Vocational Rehabilitation (VR)", "Electroconvulsive Therapy (ECT)", "Transcranial Magnetic Stimulation (TMS)", "Vagus Nerve Stimulation (VNS)", "Deep Brain Stimulation (DBS)"];


/***/ }),

/***/ "./src/muscSupply.js":
/*!***************************!*\
  !*** ./src/muscSupply.js ***!
  \***************************/
/*! exports provided: muscCon, muscMed, muscProc */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "muscCon", function() { return muscCon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "muscMed", function() { return muscMed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "muscProc", function() { return muscProc; });
var muscCon = ["Chronic Back Pain", "Bursitis", "Fibromyalgia", "Fibrous Dysplasia", "Growth Plate Injury", "Ehlers-Danlos Syndrome", "Epidermolysis Bullosa", "Marfan Syndrome", "Osteogenesis Imperfecta", "Osteoarthritis", "Rheumatoid Arthritis", "Gout", "Systemic Lupus Erythematosus (Lupus)", "Ankylosing Spondylitis", "Psoriatic Arthritis", "Reactive Arthritis", "Chondromalacia", "Meniscal Injury", "Cruciate Ligament Injury", "Medial Collateral Ligament Injury", "Lateral Collateral Ligament Injury", "Tendon Injury", "Tendinitis", "Osgood-Schlatter Disease", "Iliotibial Band Syndrome", "Osteochondritis Dissecans", "Plica Syndrome", "Osteonecrosis", "Osteoporosis", "Paget's Disease", "Scoliosis", "Spinal Stenosis", "Runner's Knee", "Bone Dislocation", "Bone Fracture", "Miscellaneous Injury", "Achilles Tendon Injury", "Chronic Grade I Sprain", "Chronic Grade II Sprain", "Chronic Grade III Sprain", "Acute Grade I Sprain", "Acute Grade II Sprain", "Acute Grade III Sprain", "Bone Cancer", "Hypophosphatemia", "Muscle Cancer"];
var muscMed = ["Ocilizumab (Actemra)", "Tocilizumab (Actemra)", "Estradiol/Norethindrone Acetate (Activella)", "Actonel", "Iaronidase (Aldurazyme)", "Alora", "Dalfampridine (Ampyra)", "Cyclobenzaprine Hydrochloride (Amrix)", "Arthrotec", "Atracurium Besylate", "Teriflunomide (Aubagio)", "Morphine Sulfate (Avinza)", "Ibandronate (Boniva)", "Onabotulinum Toxin A (Botox)", "Cerliponase Alfa (Brineura)", "Certolizumab Pegol (Cimzia)", "Colchicine (Colcrys)", "Burosumab-twza (Crysvita)", "Estrogen/Bazedoxifene (Duavee)", "Ibuprofen/Famotidine (Duexis)", "Lesinurad/Allopurinol (Duzallo)", "Taliglucerase Alfa (Elelyso)", "Deflazacort (Emflaza)", "Estradiol Tablets", "Estratab", "Etodolac", "Romosozumab-aqqg (Evenity)", "Raloxifene Hydrochloride (Evista)", "Eteplirsen (Exondyse 51)", "Interferon Beta-I B (Extavia)", "Femhrt Tablets", "Amifampridine (Firdapse)", "Teriparatide (Forteo)", "Alendronate Sodium (Fosamax)", "Somatropin (Genotropin)", "Fingolimod (Gilenya)", "Canakinumab (Ilaris)", "Kadian", "Ketoprofen", "Sarilumab (Kevzara)", "Kineret", "Pegloticase (Krystexxa)", "Alemtuzumab (Lemtrada)", "Etodolac (Lodine XL)", "Enoxaparin Sodium (Lovenox)", "Pregabalin (Lyrica)", "Cladribine (Mavenclad)", "Siponimod (Mayzent)", "Calcitonin-Salmon (Miacalcin)", "Meloxicam (Mobic)", "Myobloc", "Mirabegron (Myrbetriq)", "Galsulfase (Naglazyme)", "Naproxen Sodium (Naprelan)", "Rotigotine (Neupro)", "Ocrelizumab Ocrevus", "Baricitinib (Olumiant)", "Abatacept (Orencia)", "Apremilast (Otezla)", "Oxycodone Hydrochloride (OxyContin)", "Diclofenac Sodium (Pennsaid)", "Peginterferon beta-1a (Plegridy)", "Conjugated Estrogen (Premarin)", "Conjugated Estrogen/Medroxyprogesterone acetate (Prempro)", "Conjugated Estrogen/Medroxyprogesterone acetate (Premphase)", "Denosumab (Prolia)", "Prednisone (Rayos)", "Zoledronic acid (Reclast)", "Infliximab (Remicade)", "Upadacitinib (Rinvoq)", "Rituximab (Rituxan)", "Amifampridine (Ruzurgi)", "Vigabatrin (Sabril)", "Saizen", "Milnacipran Hydrochloride (Savella)", "Seprafilm", "Golimumab (Simponi)", "Tiludronate Disodium (Skelid)", "Eculizumab (Soliris)", "Lanreotide Acetate (Somatuline Depot)", "Pegvisomant (Somavert)", "Nusinersen (Spinraza)", "Avanafil (Stendra)", "Supartz", "Hylan GF 20 (Synvisc)", "Hylan GF 20 (Synvisc-One)", "Ixekizumab (Taltz)", "Oxycodone Hydrochloride/Naloxone Hydrochloride (Targiniq ER)", "Dimethyl Fumarate (Tecfidera)", "Testim", "Tolmetin Sodium", "Abaloparatide (Tymlos)", "Bortezomib (Velcade)", "Elosulfase Alfa (Vimizim)", "Naproxen/Esomeprazole (Vimovo)", "Rofecoxib (Vioxx)", "Estradiol (Vivelle-Dot)", "Meloxicam (Vivlodex)", "Pazopanib (Votrient)", "Diroximel Fumarate (Vumerity)", "Tofacitinib (Xeljanz)", "Tetrabenazine (Xenazine)", "Incobotulinum Toxin A (Xeomin)", "Denosumab (Xgeva)", "Collagenase Clostridium Histolyticum (Xiaflex)", "Tizanidine Hydrochloride (Zanaflex)", "Triamcinolone Acetonide (Zilretta)", "Daclizumab (Zinbryta)", "Onasemnogene Abeparvovec-xioi (Zolgensma)"];
var muscProc = ["Arthroscopy", "Computed Tomography Scan", "Muscle Biopsy", "Myelogram", "X-Ray (General)", "Bone Marrow Biopsy", "Arthrography", "Magnetic Resonance Imaging (MRI)", "Bone Biopsy", "Bone Density Test", "Bone Densitometry", "Anesthetic Injection (General)", "Physical Therapy", "Occupational Therapy", "Acupuncture/Acupressure", "Biofeedback", "Bone Scan", "Fluoroscopy Procedure", "Osteopathic Manipulation (General)"];


/***/ }),

/***/ "./src/respSupply.js":
/*!***************************!*\
  !*** ./src/respSupply.js ***!
  \***************************/
/*! exports provided: respCon, respMed, respProc */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "respCon", function() { return respCon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "respMed", function() { return respMed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "respProc", function() { return respProc; });
var respCon = ["Acute Laryngopharyngitis", "Acute Bronchitis", "Chronic Bronchitis", "Asthma", "Chronic Respiratory Disease", "Chronic Obstructive Pulmonary Disease (COPD)", "Acute Respiratory Distress Syndrome (ARDS)", "Asbestosis", "Aspergillosis", "Bronchiectasis", "Bronchiolitis", "Bronchiolitis Obliterans", "Bronchopulmonary Dysplasia", "Chronic Cough", "Coal Worker's Pneumoconiosis (Black Lung)", "Coccidioidomycosis (Valley Fever)", "Coronavirus", "COVID-19", "Cryptogenic Organizing Pneumonia (COP)", "Cystic Fibrosis (CF)", "E-cigarette or Vaping Use-Associated Lung Injury", "Emphysema", "Hantavirus Pulmonary Syndrome (HPS)", "Histoplasmosis", "Human Metapneumovirus (hMPV)", "Hypersensitivity Pneumonitis", "Idiopathic Pulmonary Fibrosis", "Influenza", "Interstitial Lung Disease", "Legionnaires' Disease", "LAM", "Mesothelioma", "Middle Eastern Respiratory Syndrome (MERS)", "Nontuberculous Mycobacteria (NTM)", "Pertussis (Whooping Cough)", "Pneumonia", "Pneumothorax (Collapsed Lung)", "Primary Ciliary Dyskinesia (PCD)", "Pulmonary Arterial Hypertension", "Pulmonary Embolism", "Pulmonary Fibrosis (PF)", "Pulmonary Hypertension", "Respiratory Syncytial Virus (RSV)", "Sarcoidosis", "Severe Acute Respiratory Syndrome (SARS)", "Shortness of Breath", "Silicosis", "Sleep Apnea", "Tuberculosis (TB)"];
var respMed = ["Ipatropium (Atrovent)", "Albuterol/Ipatropium (Combivent)", "Albuterol/Ipatropium (DuoNeb)", "Pirbuterol (Maxair Autohaler)", "Albuterol (Proventil HFA)", "Albuterol (ProAir)", "Albuterol (Ventolin HFA)", "Levalbuterol (Xopenex)", "Prednisone (Deltasone)", "Methyl-prednisolone (Medrol)", "Prednisolone (Orapred)", "Prednisolone (Prelone)", "Prednisolone (Pediapred)", "Mometasone (Asmanex)", "Ciclesonide (Alvesco)", "Fluticasone (Flovent)", "Budesonide (Pulmicort)", "Beclomethasone HFA (Qvar)", "Zafirlukast (Accolate)", "Montelukast (Singulair)", "Zileuton (Zyflo)", "Theophylline (Uniphyl)", "Theophylline (Theo-24)", "Theophylline (Other)", "Omalizumab (Xolair)", "Fluticasome/Salmeterol (Advair)", "Mometasone/Formoterol (Dulera)", "Budesonide/Formoterol (Symbicort)", "Indacaterol (Arcapta)", "Arformoterol (Brovana)", "Formoterol (Perforomist)", "Salmeterol (Serevent)", "Olodaterol (Stiverdi)", "Umeclidinium/Vilanterol (Anoro)", "Olodaterol/Tiotropium (Stiolto)", "Indacaterol/Glycopyrrolate (Utibron)", "Glycopyrrolate/Formoterol (Bevespi)", "Fluticasone (Flonase)", "Fluticasone (Veramyst)", "Triamcinolone (Nasacort)", "Triamcinolone (Nasacort AQ)", "Flunisolide (Nasarel)", "Mometasone (Nasonex)", "Budesonide (Rhinocort)", "Ciclesonide (Zetonna)", "Beclomethasone (Qnasl)", "Pseudoephedrine (Sudafed)", "Pseudoephedrine (Dimetapp)"];
var respProc = ["Minimally Invasive Thoracic Surgery (Other)", "Open Thoracic Surgery (Other)", "Bronchoscopy", "Chest Tube Procedure", "CT Scan", "CT Scan-Guided Lung Biopsy", "Endobronchial Ultrasound", "Exhaled Nitric Oxide Test", "Lobectomy", "Spirometry", "Lung Volume Testing", "Diffusing Capacity Test", "Exercise Test", "Lung Transplant", "Lung Volume Reduction Surgery", "Methacholine Challenge Test", "Oxygen Therapy", "Pulse Oximetry", "Six-Minute Walk Test", "Thoracotomy", "Stem Cell Therapy"];


/***/ }),

/***/ "./src/supplier.js":
/*!*************************!*\
  !*** ./src/supplier.js ***!
  \*************************/
/*! exports provided: onStartup, onShutdown, onConCirc, onMedCirc, onProcCirc, onConResp, onMedResp, onProcResp, onConDig, onMedDig, onProcDig, onConDiab, onMedDiab, onProcDiab, onConMusc, onMedMusc, onProcMusc, onConMent, onMedMent, onProcMent, onConGland, onMedGland, onProcGland, onConAllg, onMedAllg, onProcAllg, onConCanc, onMedCanc, onProcCanc */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onStartup", function() { return onStartup; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onShutdown", function() { return onShutdown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onConCirc", function() { return onConCirc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMedCirc", function() { return onMedCirc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onProcCirc", function() { return onProcCirc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onConResp", function() { return onConResp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMedResp", function() { return onMedResp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onProcResp", function() { return onProcResp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onConDig", function() { return onConDig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMedDig", function() { return onMedDig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onProcDig", function() { return onProcDig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onConDiab", function() { return onConDiab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMedDiab", function() { return onMedDiab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onProcDiab", function() { return onProcDiab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onConMusc", function() { return onConMusc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMedMusc", function() { return onMedMusc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onProcMusc", function() { return onProcMusc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onConMent", function() { return onConMent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMedMent", function() { return onMedMent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onProcMent", function() { return onProcMent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onConGland", function() { return onConGland; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMedGland", function() { return onMedGland; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onProcGland", function() { return onProcGland; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onConAllg", function() { return onConAllg; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMedAllg", function() { return onMedAllg; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onProcAllg", function() { return onProcAllg; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onConCanc", function() { return onConCanc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMedCanc", function() { return onMedCanc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onProcCanc", function() { return onProcCanc; });
/* harmony import */ var _circSupply_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./circSupply.js */ "./src/circSupply.js");
/* harmony import */ var _respSupply_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./respSupply.js */ "./src/respSupply.js");
/* harmony import */ var _digSupply_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./digSupply.js */ "./src/digSupply.js");
/* harmony import */ var _diabSupply_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./diabSupply.js */ "./src/diabSupply.js");
/* harmony import */ var _muscSupply_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./muscSupply.js */ "./src/muscSupply.js");
/* harmony import */ var _mentSupply_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./mentSupply.js */ "./src/mentSupply.js");
/* harmony import */ var _glandSupply_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./glandSupply.js */ "./src/glandSupply.js");
/* harmony import */ var _allgSupply_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./allgSupply.js */ "./src/allgSupply.js");
/* harmony import */ var _cancSupply_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./cancSupply.js */ "./src/cancSupply.js");




























var sketch = __webpack_require__(/*! sketch */ "sketch");

var DataSupplier = sketch.DataSupplier;

var util = __webpack_require__(/*! util */ "util");

function onStartup() {
  // Conditions (Suppliers)
  DataSupplier.registerDataSupplier('public.text', 'Conditions - Circulatory', 'ConCirc');
  DataSupplier.registerDataSupplier('public.text', 'Medications - Circulatory', 'MedCirc');
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Circulatory', 'ProcCirc');
  DataSupplier.registerDataSupplier('public.text', 'Conditions - Respiratory', 'ConResp');
  DataSupplier.registerDataSupplier('public.text', 'Medications - Respiratory', 'MedResp');
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Respiratory', 'ProcResp');
  DataSupplier.registerDataSupplier('public.text', 'Conditions - Digestive', 'ConDig');
  DataSupplier.registerDataSupplier('public.text', 'Medications - Digestive', 'MedDig');
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Digestive', 'ProcDig');
  DataSupplier.registerDataSupplier('public.text', 'Conditions - Diabetic', 'ConDiab');
  DataSupplier.registerDataSupplier('public.text', 'Medications - Diabetic', 'MedDiab');
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Diabetic', 'ProcDiab');
  DataSupplier.registerDataSupplier('public.text', 'Conditions - Musculoskeletal', 'ConMusc');
  DataSupplier.registerDataSupplier('public.text', 'Medications - Musculoskeletal', 'MedMusc');
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Musculoskeletal', 'ProcMusc');
  DataSupplier.registerDataSupplier('public.text', 'Conditions - Mental', 'ConMent');
  DataSupplier.registerDataSupplier('public.text', 'Medications - Mental', 'MedMent');
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Mental', 'ProcMent');
  DataSupplier.registerDataSupplier('public.text', 'Conditions - Glandular', 'ConGland');
  DataSupplier.registerDataSupplier('public.text', 'Medications - Glandular', 'MedGland');
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Glandular', 'ProcGland');
  DataSupplier.registerDataSupplier('public.text', 'Conditions - Allergies', 'ConAllg');
  DataSupplier.registerDataSupplier('public.text', 'Medications - Allergies', 'MedAllg');
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Allergies', 'ProcAllg');
  DataSupplier.registerDataSupplier('public.text', 'Conditions - Cancers', 'ConCanc');
  DataSupplier.registerDataSupplier('public.text', 'Medications - Cancer', 'MedCanc');
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Cancer', 'ProcCanc');
}
function onShutdown() {
  // Deregister the plugin
  DataSupplier.deregisterDataSuppliers();
} // START - CIRCULATORY

function onConCirc(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var circConSupply = _circSupply_js__WEBPACK_IMPORTED_MODULE_0__["circCon"][Math.floor(Math.random() * _circSupply_js__WEBPACK_IMPORTED_MODULE_0__["circCon"].length)];
    var data = circConSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onMedCirc(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var circMedSupply = _circSupply_js__WEBPACK_IMPORTED_MODULE_0__["circMed"][Math.floor(Math.random() * _circSupply_js__WEBPACK_IMPORTED_MODULE_0__["circMed"].length)];
    var data = circMedSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onProcCirc(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var circProcSupply = _circSupply_js__WEBPACK_IMPORTED_MODULE_0__["circProc"][Math.floor(Math.random() * _circSupply_js__WEBPACK_IMPORTED_MODULE_0__["circProc"].length)];
    var data = circProcSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
} // START - RESPIRATORY

function onConResp(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var respConSupply = _respSupply_js__WEBPACK_IMPORTED_MODULE_1__["respCon"][Math.floor(Math.random() * _respSupply_js__WEBPACK_IMPORTED_MODULE_1__["respCon"].length)];
    var data = respConSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onMedResp(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var respMedSupply = _respSupply_js__WEBPACK_IMPORTED_MODULE_1__["respMed"][Math.floor(Math.random() * _respSupply_js__WEBPACK_IMPORTED_MODULE_1__["respMed"].length)];
    var data = respMedSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onProcResp(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var respProcSupply = _respSupply_js__WEBPACK_IMPORTED_MODULE_1__["respProc"][Math.floor(Math.random() * _respSupply_js__WEBPACK_IMPORTED_MODULE_1__["respProc"].length)];
    var data = respProcSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
} // START - DIGESTIVE

function onConDig(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var digConSupply = _digSupply_js__WEBPACK_IMPORTED_MODULE_2__["digCon"][Math.floor(Math.random() * _digSupply_js__WEBPACK_IMPORTED_MODULE_2__["digCon"].length)];
    var data = digConSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onMedDig(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var digMedSupply = _digSupply_js__WEBPACK_IMPORTED_MODULE_2__["digMed"][Math.floor(Math.random() * _digSupply_js__WEBPACK_IMPORTED_MODULE_2__["digMed"].length)];
    var data = digMedSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onProcDig(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var digProcSupply = _digSupply_js__WEBPACK_IMPORTED_MODULE_2__["digProc"][Math.floor(Math.random() * _digSupply_js__WEBPACK_IMPORTED_MODULE_2__["digProc"].length)];
    var data = digProcSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
} // START - DIABETES

function onConDiab(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var diabConSupply = _diabSupply_js__WEBPACK_IMPORTED_MODULE_3__["diabCon"][Math.floor(Math.random() * _diabSupply_js__WEBPACK_IMPORTED_MODULE_3__["diabCon"].length)];
    var data = diabConSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onMedDiab(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var diabMedSupply = _diabSupply_js__WEBPACK_IMPORTED_MODULE_3__["diabMed"][Math.floor(Math.random() * _diabSupply_js__WEBPACK_IMPORTED_MODULE_3__["diabMed"].length)];
    var data = diabMedSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onProcDiab(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var diabProcSupply = _diabSupply_js__WEBPACK_IMPORTED_MODULE_3__["diabProc"][Math.floor(Math.random() * _diabSupply_js__WEBPACK_IMPORTED_MODULE_3__["diabProc"].length)];
    var data = diabProcSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
} // START - MUSCULOSKELETAL

function onConMusc(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var muscConSupply = _muscSupply_js__WEBPACK_IMPORTED_MODULE_4__["muscCon"][Math.floor(Math.random() * _muscSupply_js__WEBPACK_IMPORTED_MODULE_4__["muscCon"].length)];
    var data = muscConSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onMedMusc(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var muscMedSupply = _muscSupply_js__WEBPACK_IMPORTED_MODULE_4__["muscMed"][Math.floor(Math.random() * _muscSupply_js__WEBPACK_IMPORTED_MODULE_4__["muscMed"].length)];
    var data = muscMedSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onProcMusc(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var muscProcSupply = _muscSupply_js__WEBPACK_IMPORTED_MODULE_4__["muscProc"][Math.floor(Math.random() * _muscSupply_js__WEBPACK_IMPORTED_MODULE_4__["muscProc"].length)];
    var data = muscProcSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
} // START - MENTAL

function onConMent(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var mentConSupply = _mentSupply_js__WEBPACK_IMPORTED_MODULE_5__["mentCon"][Math.floor(Math.random() * _mentSupply_js__WEBPACK_IMPORTED_MODULE_5__["mentCon"].length)];
    var data = mentConSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onMedMent(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var mentMedSupply = _mentSupply_js__WEBPACK_IMPORTED_MODULE_5__["mentMed"][Math.floor(Math.random() * _mentSupply_js__WEBPACK_IMPORTED_MODULE_5__["mentMed"].length)];
    var data = mentMedSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onProcMent(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var mentProcSupply = _mentSupply_js__WEBPACK_IMPORTED_MODULE_5__["mentProc"][Math.floor(Math.random() * _mentSupply_js__WEBPACK_IMPORTED_MODULE_5__["mentProc"].length)];
    var data = mentProcSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
} // START - GLANDULAR

function onConGland(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var glandConSupply = _glandSupply_js__WEBPACK_IMPORTED_MODULE_6__["glandCon"][Math.floor(Math.random() * _glandSupply_js__WEBPACK_IMPORTED_MODULE_6__["glandCon"].length)];
    var data = glandConSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onMedGland(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var glandMedSupply = _glandSupply_js__WEBPACK_IMPORTED_MODULE_6__["glandMed"][Math.floor(Math.random() * _glandSupply_js__WEBPACK_IMPORTED_MODULE_6__["glandMed"].length)];
    var data = glandMedSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onProcGland(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var glandProcSupply = _glandSupply_js__WEBPACK_IMPORTED_MODULE_6__["glandProc"][Math.floor(Math.random() * _glandSupply_js__WEBPACK_IMPORTED_MODULE_6__["glandProc"].length)];
    var data = glandProcSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
} // START - ALLERGIES

function onConAllg(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var allgConSupply = _allgSupply_js__WEBPACK_IMPORTED_MODULE_7__["allgCon"][Math.floor(Math.random() * _allgSupply_js__WEBPACK_IMPORTED_MODULE_7__["allgCon"].length)];
    var data = allgConSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onMedAllg(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var allgMedSupply = _allgSupply_js__WEBPACK_IMPORTED_MODULE_7__["allgMed"][Math.floor(Math.random() * _allgSupply_js__WEBPACK_IMPORTED_MODULE_7__["allgMed"].length)];
    var data = allgMedSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onProcAllg(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var allgProcSupply = _allgSupply_js__WEBPACK_IMPORTED_MODULE_7__["allgProc"][Math.floor(Math.random() * _allgSupply_js__WEBPACK_IMPORTED_MODULE_7__["allgProc"].length)];
    var data = allgProcSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
} // START - CANCER

function onConCanc(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var cancConSupply = _cancSupply_js__WEBPACK_IMPORTED_MODULE_8__["cancCon"][Math.floor(Math.random() * _cancSupply_js__WEBPACK_IMPORTED_MODULE_8__["cancCon"].length)];
    var data = cancConSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onMedCanc(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var cancMedSupply = _cancSupply_js__WEBPACK_IMPORTED_MODULE_8__["cancMed"][Math.floor(Math.random() * _cancSupply_js__WEBPACK_IMPORTED_MODULE_8__["cancMed"].length)];
    var data = cancMedSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onProcCanc(context) {
  var dataKey = context.data.key;
  var dataCount = context.data.requestedCount;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (_, index) {
    var cancProcSupply = _cancSupply_js__WEBPACK_IMPORTED_MODULE_8__["cancProc"][Math.floor(Math.random() * _cancSupply_js__WEBPACK_IMPORTED_MODULE_8__["cancProc"].length)];
    var data = cancProcSupply;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ })

/******/ });
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onStartup'] = __skpm_run.bind(this, 'onStartup');
that['onShutdown'] = __skpm_run.bind(this, 'onShutdown');
that['onConCirc'] = __skpm_run.bind(this, 'onConCirc');
that['onMedCirc'] = __skpm_run.bind(this, 'onMedCirc');
that['onProcCirc'] = __skpm_run.bind(this, 'onProcCirc');
that['onConResp'] = __skpm_run.bind(this, 'onConResp');
that['onMedResp'] = __skpm_run.bind(this, 'onMedResp');
that['onProcResp'] = __skpm_run.bind(this, 'onProcResp');
that['onConDig'] = __skpm_run.bind(this, 'onConDig');
that['onMedDig'] = __skpm_run.bind(this, 'onMedDig');
that['onProcDig'] = __skpm_run.bind(this, 'onProcDig');
that['onConDiab'] = __skpm_run.bind(this, 'onConDiab');
that['onMedDiab'] = __skpm_run.bind(this, 'onMedDiab');
that['onProcDiab'] = __skpm_run.bind(this, 'onProcDiab');
that['onConMusc'] = __skpm_run.bind(this, 'onConMusc');
that['onMedMusc'] = __skpm_run.bind(this, 'onMedMusc');
that['onProcMusc'] = __skpm_run.bind(this, 'onProcMusc');
that['onConMent'] = __skpm_run.bind(this, 'onConMent');
that['onMedMent'] = __skpm_run.bind(this, 'onMedMent');
that['onProcMent'] = __skpm_run.bind(this, 'onProcMent');
that['onConGland'] = __skpm_run.bind(this, 'onConGland');
that['onMedGland'] = __skpm_run.bind(this, 'onMedGland');
that['onProcGland'] = __skpm_run.bind(this, 'onProcGland');
that['onConAllg'] = __skpm_run.bind(this, 'onConAllg');
that['onMedAllg'] = __skpm_run.bind(this, 'onMedAllg');
that['onProcAllg'] = __skpm_run.bind(this, 'onProcAllg');
that['onConCanc'] = __skpm_run.bind(this, 'onConCanc');
that['onMedCanc'] = __skpm_run.bind(this, 'onMedCanc');
that['onProcCanc'] = __skpm_run.bind(this, 'onProcCanc');
that['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=supplier.js.map