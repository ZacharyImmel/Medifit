import { circCon } from './circSupply.js';
import { circMed } from './circSupply.js';
import { circProc } from './circSupply.js';

import { respCon } from './respSupply.js';
import { respMed } from './respSupply.js';
import { respProc } from './respSupply.js';

import { digCon } from './digSupply.js';
import { digMed } from './digSupply.js';
import { digProc } from './digSupply.js';

import { diabCon } from './diabSupply.js';
import { diabMed } from './diabSupply.js';
import { diabProc } from './diabSupply.js';

import { muscCon } from './muscSupply.js';
import { muscMed } from './muscSupply.js';
import { muscProc } from './muscSupply.js';

import { mentCon } from './mentSupply.js';
import { mentMed } from './mentSupply.js';
import { mentProc } from './mentSupply.js';

import { glandCon } from './glandSupply.js';
import { glandMed } from './glandSupply.js';
import { glandProc } from './glandSupply.js';

import { allgCon } from './allgSupply.js';
import { allgMed } from './allgSupply.js';
import { allgProc } from './allgSupply.js';

import { cancCon } from './cancSupply.js';
import { cancMed } from './cancSupply.js';
import { cancProc } from './cancSupply.js';

const sketch = require('sketch')
const { DataSupplier } = sketch
const util = require('util')

export function onStartup () {
  // Conditions (Suppliers)
  DataSupplier.registerDataSupplier('public.text', 'Conditions - Circulatory', 'ConCirc')
  DataSupplier.registerDataSupplier('public.text', 'Medications - Circulatory', 'MedCirc')
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Circulatory', 'ProcCirc')

  DataSupplier.registerDataSupplier('public.text', 'Conditions - Respiratory', 'ConResp')
  DataSupplier.registerDataSupplier('public.text', 'Medications - Respiratory', 'MedResp')
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Respiratory', 'ProcResp')

  DataSupplier.registerDataSupplier('public.text', 'Conditions - Digestive', 'ConDig')
  DataSupplier.registerDataSupplier('public.text', 'Medications - Digestive', 'MedDig')
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Digestive', 'ProcDig')

  DataSupplier.registerDataSupplier('public.text', 'Conditions - Diabetic', 'ConDiab')
  DataSupplier.registerDataSupplier('public.text', 'Medications - Diabetic', 'MedDiab')
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Diabetic', 'ProcDiab')

  DataSupplier.registerDataSupplier('public.text', 'Conditions - Musculoskeletal', 'ConMusc')
  DataSupplier.registerDataSupplier('public.text', 'Medications - Musculoskeletal', 'MedMusc')
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Musculoskeletal', 'ProcMusc')

  DataSupplier.registerDataSupplier('public.text', 'Conditions - Mental', 'ConMent')
  DataSupplier.registerDataSupplier('public.text', 'Medications - Mental', 'MedMent')
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Mental', 'ProcMent')

  DataSupplier.registerDataSupplier('public.text', 'Conditions - Glandular', 'ConGland')
  DataSupplier.registerDataSupplier('public.text', 'Medications - Glandular', 'MedGland')
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Glandular', 'ProcGland')

  DataSupplier.registerDataSupplier('public.text', 'Conditions - Allergies', 'ConAllg')
  DataSupplier.registerDataSupplier('public.text', 'Medications - Allergies', 'MedAllg')
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Allergies', 'ProcAllg')

  DataSupplier.registerDataSupplier('public.text', 'Conditions - Cancers', 'ConCanc')
  DataSupplier.registerDataSupplier('public.text', 'Medications - Cancer', 'MedCanc')
  DataSupplier.registerDataSupplier('public.text', 'Treatments - Cancer', 'ProcCanc')
}

export function onShutdown () {
  // Deregister the plugin
  DataSupplier.deregisterDataSuppliers()
}

// START - CIRCULATORY
export function onConCirc (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var circConSupply = circCon[Math.floor(Math.random() * circCon.length)];
  let data = circConSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onMedCirc (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var circMedSupply = circMed[Math.floor(Math.random() * circMed.length)];
  let data = circMedSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onProcCirc (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var circProcSupply = circProc[Math.floor(Math.random() * circProc.length)];
  let data = circProcSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}


// START - RESPIRATORY
export function onConResp (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var respConSupply = respCon[Math.floor(Math.random() * respCon.length)];
  let data = respConSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onMedResp (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var respMedSupply = respMed[Math.floor(Math.random() * respMed.length)];
  let data = respMedSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onProcResp (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var respProcSupply = respProc[Math.floor(Math.random() * respProc.length)];
  let data = respProcSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}


// START - DIGESTIVE
export function onConDig (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var digConSupply = digCon[Math.floor(Math.random() * digCon.length)];
  let data = digConSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onMedDig (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var digMedSupply = digMed[Math.floor(Math.random() * digMed.length)];
  let data = digMedSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onProcDig (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var digProcSupply = digProc[Math.floor(Math.random() * digProc.length)];
  let data = digProcSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}


// START - DIABETES
export function onConDiab (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var diabConSupply = diabCon[Math.floor(Math.random() * diabCon.length)];
  let data = diabConSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onMedDiab (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var diabMedSupply = diabMed[Math.floor(Math.random() * diabMed.length)];
  let data = diabMedSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onProcDiab (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var diabProcSupply = diabProc[Math.floor(Math.random() * diabProc.length)];
  let data = diabProcSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}


// START - MUSCULOSKELETAL
export function onConMusc (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var muscConSupply = muscCon[Math.floor(Math.random() * muscCon.length)];
  let data = muscConSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onMedMusc (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var muscMedSupply = muscMed[Math.floor(Math.random() * muscMed.length)];
  let data = muscMedSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onProcMusc (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var muscProcSupply = muscProc[Math.floor(Math.random() * muscProc.length)];
  let data = muscProcSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}


// START - MENTAL
export function onConMent (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var mentConSupply = mentCon[Math.floor(Math.random() * mentCon.length)];
  let data = mentConSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onMedMent (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var mentMedSupply = mentMed[Math.floor(Math.random() * mentMed.length)];
  let data = mentMedSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onProcMent (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var mentProcSupply = mentProc[Math.floor(Math.random() * mentProc.length)];
  let data = mentProcSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}


// START - GLANDULAR
export function onConGland (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var glandConSupply = glandCon[Math.floor(Math.random() * glandCon.length)];
  let data = glandConSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onMedGland (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var glandMedSupply = glandMed[Math.floor(Math.random() * glandMed.length)];
  let data = glandMedSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onProcGland (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var glandProcSupply = glandProc[Math.floor(Math.random() * glandProc.length)];
  let data = glandProcSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}


// START - ALLERGIES
export function onConAllg (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var allgConSupply = allgCon[Math.floor(Math.random() * allgCon.length)];
  let data = allgConSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onMedAllg (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var allgMedSupply = allgMed[Math.floor(Math.random() * allgMed.length)];
  let data = allgMedSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onProcAllg (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var allgProcSupply = allgProc[Math.floor(Math.random() * allgProc.length)];
  let data = allgProcSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}


// START - CANCER
export function onConCanc (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var cancConSupply = cancCon[Math.floor(Math.random() * cancCon.length)];
  let data = cancConSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onMedCanc (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var cancMedSupply = cancMed[Math.floor(Math.random() * cancMed.length)];
  let data = cancMedSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

export function onProcCanc (context) {
  let dataKey = context.data.key
  var dataCount = context.data.requestedCount;
  const items = util.toArray(context.data.items).map(sketch.fromNative)
items.forEach((_, index) => {
  var cancProcSupply = cancProc[Math.floor(Math.random() * cancProc.length)];
  let data = cancProcSupply;
DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
